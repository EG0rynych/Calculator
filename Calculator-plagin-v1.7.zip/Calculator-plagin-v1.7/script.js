const displayEl = document.getElementById('display');
const prevueEl = document.getElementById('prevue');
const numberButtons = document.querySelectorAll('.btn.number');
const btnEquals = document.getElementById('btn-equals'); 
const btnClear = document.getElementById('btn-clear');     
const btnDecimal = document.getElementById('btn-decimal');   
const btnSign = document.getElementById('btn-sign');      
const btnPercent = document.getElementById('btn-percent');
const btnDivide = document.getElementById('btn-divide');
const btnMultiply = document.getElementById('btn-multiply');
const btnMinus = document.getElementById('btn-minus');
const btnPlus = document.getElementById('btn-plus');
const btnColor = document.getElementById('btn-color');
const savedTheme = localStorage.getItem('theme');
let shouldResetDisplay = false;
let firstOperand = '';
let operator = '';

if (savedTheme === 'dark') {
  document.body.classList.add('dark');
  btnColor.textContent = '☀️ Тема';
} else {
  document.body.classList.remove('dark');
  btnColor.textContent = '🌙 Тема';
}
displayEl.addEventListener('keydown', (event) => {
   if(event.key === 'Tab') {
      event.preventDefault();
      document.getElementById('btn-clear').focus();
   }
})
btnColor.addEventListener('click', () => {
   document.body.classList.toggle('dark');
   const isDark = document.body.classList.contains('dark');
   btnColor.textContent = isDark ? '☀️ Тема' : '🌙 Тема';
   localStorage.setItem('theme', isDark ? 'dark' : 'light');
})
numberButtons.forEach(btn => {
  btn.addEventListener('click', () => {
    appendNumber(btn.textContent);
  });
});

function appendNumber(number) {
  if (shouldResetDisplay) {
    displayEl.value = '';
    shouldResetDisplay = false;
  }
  displayEl.value += number;
  if (displayEl.value.length > 0) {
    btnClear.textContent = 'C';
  }
}

const allowedKeys = [
  '0','1','2','3','4','5','6','7','8','9',
  '.', '+', '-', '*', '/', '%',
  'Backspace', 'ArrowLeft', 'ArrowRight', 'Delete', 'Enter'
];

displayEl.addEventListener('keydown', (event) => {
  if (!allowedKeys.includes(event.key)) {
    event.preventDefault();
  }
});

btnClear.addEventListener('click', () => {
  displayEl.value = '';
  btnClear.textContent = 'AC';
  firstOperand = '';
  operator = '';
  shouldResetDisplay = false;
  prevueEl.textContent = '';
});

function handleOperator(op) {
  if (firstOperand !== '' && operator !== '') {
    const result = calculate(firstOperand, displayEl.value, operator);
    displayEl.value = result;
    firstOperand = result;
  } else {
    firstOperand = displayEl.value;
  }
  operator = op;
  shouldResetDisplay = true;
  if (firstOperand !== '') {
    prevueEl.innerHTML = `${firstOperand} <b>${operator}</b>`;
  }
}

btnPlus.addEventListener('click', () => handleOperator('+'));
btnMinus.addEventListener('click', () => handleOperator('-'));
btnMultiply.addEventListener('click', () => handleOperator('*'));
btnDivide.addEventListener('click', () => handleOperator('/'));

function calculate(a, b, op) {
  const numA = Number(a);
  const numB = Number(b);
  if (op === '+') return numA + numB;
  if (op === '-') return numA - numB;
  if (op === '*') return numA * numB;
  if (op === '/') {
    if (numB === 0) return 'Ошибка';
    return numA / numB;
  }
}
btnPercent.addEventListener('click', () => {
    const number = +displayEl.value;
    const result = number / 100;
    displayEl.value = result;
})
btnSign.addEventListener('click', () => {
   const number = +displayEl.value;
   if (number === 0 || isNaN(number)) return;
   const result = number * -1;
   displayEl.value = result;
})
btnDecimal.addEventListener('click', () => {
   if (shouldResetDisplay) {
      displayEl.value = '0.';
      shouldResetDisplay = false;
      return;
   }
   if (!displayEl.value.includes('.')) {
      if(displayEl.value === '') {
         displayEl.value = '0.';
      } else {
         displayEl.value += '.';
      }
   }
})

btnEquals.addEventListener('click', () => {
  if (!operator || firstOperand === '') return;
  const secondOperand = displayEl.value;
  const result = calculate(firstOperand, secondOperand, operator);
  prevueEl.textContent = `${firstOperand} ${operator} ${secondOperand} =`;
  displayEl.value = result;
  if (result !== 'Ошибка') {
    firstOperand = result;
  } else {
    firstOperand = '';
  }
  operator = '';
  shouldResetDisplay = true;
});
document.addEventListener('keydown', (event) => {
   const key = event.key;
   if (!allowedKeys.includes(key)) return;
   
   if (key >= '0' && key <= '9') {
    event.preventDefault();
    appendNumber(key);
  } else if (key === '.') {
    event.preventDefault();
    btnDecimal.click();
  } else if (key === '+') {
    event.preventDefault();
    btnPlus.click();
  } else if (key === '-') {
    event.preventDefault();
    btnMinus.click();
  } else if (key === '*') {
    event.preventDefault();
    btnMultiply.click();
  } else if (key === '/') {
    event.preventDefault();
    btnDivide.click();
  } else if (key === '%') {
    event.preventDefault();
    btnPercent.click();
  } else if (key === 'Enter') {
    event.preventDefault();
    btnEquals.click();
  } else if (key === 'Backspace') {
    event.preventDefault();
    displayEl.value = displayEl.value.slice(0, -1);
    if (displayEl.value === '') {
      btnClear.textContent = 'AC';
    }
  } else if (key === 'Delete') {
    event.preventDefault();
    btnClear.click();
  }
});